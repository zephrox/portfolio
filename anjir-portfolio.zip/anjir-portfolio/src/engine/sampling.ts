import type { Layout, Region, RegionFrac } from './types';

export type DrawFn = (c: CanvasRenderingContext2D, w: number, h: number) => void;

export const SHAPE_FONT = '"Anek Bangla", "Archivo", sans-serif';

export function regionFromFrac(f: RegionFrac, layout: Layout): Region {
  return { x0: layout.width * f.x, y0: layout.height * f.y, w: layout.width * f.w, h: layout.height * f.h };
}

/** Draws into an offscreen canvas and returns the filled pixels as viewport points [x0, y0, x1, y1, ...]. */
export function samplePixels(region: Region, draw: DrawFn, step = 2): number[] {
  const w = Math.max(1, Math.round(region.w));
  const h = Math.max(1, Math.round(region.h));
  const off = document.createElement('canvas');
  off.width = w;
  off.height = h;
  const c = off.getContext('2d');
  if (!c) return [];
  c.fillStyle = '#000';
  c.strokeStyle = '#000';
  c.lineCap = 'round';
  c.lineJoin = 'round';
  draw(c, w, h);
  const data = c.getImageData(0, 0, w, h).data;
  const pts: number[] = [];
  for (let y = 0; y < h; y += step) {
    for (let x = 0; x < w; x += step) {
      if (data[(y * w + x) * 4 + 3] > 110) {
        pts.push(region.x0 + x + (Math.random() - 0.5) * step, region.y0 + y + (Math.random() - 0.5) * step);
      }
    }
  }
  return pts;
}

/** Spreads `count` particles over the sampled points, reusing points with a little jitter if there are too few. */
export function fillTargets(out: Float32Array, pts: number[], from: number, count: number, jitter: number): void {
  const n = pts.length / 2;
  if (!n) return;
  const order = new Uint32Array(n);
  for (let i = 0; i < n; i++) order[i] = i;
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = order[i];
    order[i] = order[j];
    order[j] = t;
  }
  for (let i = 0; i < count; i++) {
    const k = order[i % n];
    const j = i >= n ? jitter : 0;
    out[(from + i) * 2] = pts[k * 2] + (Math.random() - 0.5) * j;
    out[(from + i) * 2 + 1] = pts[k * 2 + 1] + (Math.random() - 0.5) * j;
  }
}

/** Fills the box with centred lines of large text. */
export function fitText(c: CanvasRenderingContext2D, w: number, h: number, lines: string[]): void {
  let fs = (h / lines.length) * 0.72;
  c.font = `700 ${fs}px ${SHAPE_FONT}`;
  const mw = Math.max(...lines.map((l) => c.measureText(l).width));
  if (mw > w * 0.94) {
    fs *= (w * 0.94) / mw;
    c.font = `700 ${fs}px ${SHAPE_FONT}`;
  }
  c.textAlign = 'center';
  c.textBaseline = 'alphabetic';
  const lh = fs * 1.12;
  const total = lh * lines.length;
  lines.forEach((l, i) => {
    const m = c.measureText(l);
    const asc = m.actualBoundingBoxAscent || fs * 0.7;
    const desc = m.actualBoundingBoxDescent || fs * 0.2;
    const cy = h / 2 - total / 2 + lh * (i + 0.5);
    c.fillText(l, w / 2, cy + (asc - desc) / 2);
  });
}

/**
 * Samples a real DOM heading so particles can land exactly on its letters.
 * Uses offsets (not getBoundingClientRect) so CSS reveal transforms don't shift the result.
 */
export function headingPoints(el: HTMLElement | null, root: HTMLElement): number[] {
  if (!el) return [];
  let x = 0;
  let y = 0;
  let n: HTMLElement | null = el;
  while (n && n !== root) {
    x += n.offsetLeft;
    y += n.offsetTop;
    n = n.offsetParent as HTMLElement | null;
  }
  const region: Region = { x0: x, y0: y, w: el.offsetWidth, h: el.offsetHeight + 12 };
  const cs = getComputedStyle(el);
  const fs = parseFloat(cs.fontSize) || 48;
  const lh = parseFloat(cs.lineHeight) || fs * 1.05;
  const center = cs.textAlign === 'center';
  const text = (el.textContent || '').replace(/\s+/g, ' ').trim();
  return samplePixels(
    region,
    (c, w) => {
      c.font = `${cs.fontWeight || '800'} ${fs}px ${cs.fontFamily}`;
      c.textBaseline = 'alphabetic';
      const lines: string[] = [];
      let cur = '';
      for (const word of text.split(' ')) {
        const t = cur ? `${cur} ${word}` : word;
        if (c.measureText(t).width > w + 1 && cur) {
          lines.push(cur);
          cur = word;
        } else cur = t;
      }
      if (cur) lines.push(cur);
      const m = c.measureText('Hg');
      const asc = m.fontBoundingBoxAscent || fs * 0.9;
      const desc = m.fontBoundingBoxDescent || fs * 0.22;
      lines.forEach((l, i) => {
        const lx = center ? (w - c.measureText(l).width) / 2 : 0;
        c.fillText(l, lx, i * lh + (lh - (asc + desc)) / 2 + asc);
      });
    },
    fs > 70 ? 3 : 2,
  );
}
