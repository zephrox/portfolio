import { fillTargets, fitText, samplePixels, type DrawFn } from '../sampling';
import type { BodyShape, ShapeBuildContext } from '../types';

/** Turns any 2D drawing into particle targets inside the section's region. */
export function fromDrawing(ctx: ShapeBuildContext, draw: DrawFn, step = 2): BodyShape {
  const pos = new Float32Array(ctx.count * 2);
  const alpha = new Float32Array(ctx.count).fill(ctx.alpha);
  const pts = samplePixels(ctx.region, draw, step);
  if (pts.length) fillTargets(pos, pts, 0, ctx.count, 2.5);
  return { pos, alpha, anchor: { x: ctx.region.x0 + ctx.region.w / 2, y: ctx.region.y0 + ctx.region.h / 2 } };
}

export function buildText(ctx: ShapeBuildContext, lines: string[]): BodyShape {
  return fromDrawing(ctx, (c, w, h) => fitText(c, w, h, lines));
}

export function buildOrbits(ctx: ShapeBuildContext): BodyShape {
  return fromDrawing(ctx, (c, w, h) => {
    const r = Math.min(w, h) * 0.46;
    const cx = w / 2;
    const cy = h / 2;
    c.lineWidth = 2.4;
    [0, Math.PI / 3, (2 * Math.PI) / 3].forEach((a, j) => {
      c.save();
      c.translate(cx, cy);
      c.rotate(a);
      c.beginPath();
      c.ellipse(0, 0, r, r * 0.34, 0, 0, Math.PI * 2);
      c.stroke();
      const t = j * 2.1;
      c.beginPath();
      c.arc(r * Math.cos(t), r * 0.34 * Math.sin(t), 8, 0, Math.PI * 2);
      c.fill();
      c.restore();
    });
    c.beginPath();
    c.arc(cx, cy, r * 0.09, 0, Math.PI * 2);
    c.fill();
  });
}

export function buildSeismic(ctx: ShapeBuildContext, rows: number): BodyShape {
  return fromDrawing(ctx, (c, w, h) => {
    c.lineWidth = 2.2;
    for (let r = 0; r < rows; r++) {
      const y0 = (h * (r + 0.5)) / rows;
      const bx = w * (0.15 + Math.random() * 0.7);
      const sd = w * 0.04;
      c.beginPath();
      for (let x = 0; x <= w; x += 3) {
        const burst = Math.exp(-((x - bx) * (x - bx)) / (2 * sd * sd));
        const amp = (h / rows) * 0.45 * burst + 2;
        const y = y0 + Math.sin(x * 0.35 + r) * amp * Math.sin(x * 0.09 + r * 2);
        if (x === 0) c.moveTo(x, y);
        else c.lineTo(x, y);
      }
      c.stroke();
    }
  });
}

/** A 468-point face mesh, like MediaPipe FaceMesh, seen at a slight angle. */
export function buildFaceMesh(ctx: ShapeBuildContext): BodyShape {
  const mesh = meshPoints();
  return fromDrawing(ctx, (c, w, h) => {
    const yaw = -0.32;
    const cy0 = Math.cos(yaw);
    const sy0 = Math.sin(yaw);
    const s = Math.min(w / 1.8, h / 2.3);
    const cx = w / 2;
    const cy = h / 2;
    const pr = mesh.map(([X, Y, Z]) => [cx + (X * cy0 + Z * sy0) * s, cy - Y * s]);
    c.lineWidth = 1.3;
    for (let i = 0; i < mesh.length; i++) {
      const best: [number, number][] = [];
      for (let j = 0; j < mesh.length; j++) {
        if (j === i) continue;
        const dx = mesh[i][0] - mesh[j][0];
        const dy = mesh[i][1] - mesh[j][1];
        const dz = mesh[i][2] - mesh[j][2];
        const d2 = dx * dx + dy * dy + dz * dz;
        if (best.length < 2 || d2 < best[best.length - 1][0]) {
          best.push([d2, j]);
          best.sort((a, b) => a[0] - b[0]);
          if (best.length > 2) best.pop();
        }
      }
      for (const [, j] of best) {
        c.beginPath();
        c.moveTo(pr[i][0], pr[i][1]);
        c.lineTo(pr[j][0], pr[j][1]);
        c.stroke();
      }
    }
    for (const [px, py] of pr) {
      c.beginPath();
      c.arc(px, py, 3, 0, Math.PI * 2);
      c.fill();
    }
  });
}

export function buildWindows(ctx: ShapeBuildContext): BodyShape {
  return fromDrawing(ctx, (c, w, h) => {
    const path = (x: number, y: number, ww: number, hh: number, r: number) => {
      c.beginPath();
      c.moveTo(x + r, y);
      c.arcTo(x + ww, y, x + ww, y + hh, r);
      c.arcTo(x + ww, y + hh, x, y + hh, r);
      c.arcTo(x, y + hh, x, y, r);
      c.arcTo(x, y, x + ww, y, r);
      c.closePath();
    };
    const bw = w * 0.62;
    const bh = h * 0.52;
    const wins: [number, number][] = [[w * 0.04, h * 0.06], [w * 0.19, h * 0.24], [w * 0.34, h * 0.42]];
    c.lineWidth = 3;
    wins.forEach(([x, y], j) => {
      c.globalCompositeOperation = 'destination-out';
      path(x, y, bw, bh, 10);
      c.fill();
      c.globalCompositeOperation = 'source-over';
      path(x, y, bw, bh, 10);
      c.stroke();
      c.beginPath();
      c.moveTo(x, y + 30);
      c.lineTo(x + bw, y + 30);
      c.stroke();
      for (let k = 0; k < 3; k++) {
        c.beginPath();
        c.arc(x + 18 + k * 14, y + 15, 4, 0, Math.PI * 2);
        c.fill();
      }
      if (j === 2) {
        [0.7, 0.55, 0.82, 0.4, 0.64].forEach((f, r) => c.fillRect(x + 22, y + 54 + r * ((bh - 74) / 5), (bw - 44) * f, 7));
      }
    });
  });
}

function meshPoints(): [number, number, number][] {
  let pts: [number, number, number][] = [];
  let N = 800;
  const ga = Math.PI * (3 - Math.sqrt(5));
  while (pts.length < 468) {
    pts = [];
    for (let i = 0; i < N; i++) {
      const y = 1 - (2 * (i + 0.5)) / N;
      const r = Math.sqrt(1 - y * y);
      const th = ga * i;
      const z = Math.sin(th) * r;
      if (z > -0.15) pts.push([Math.cos(th) * r, y, z]);
    }
    N += 4;
  }
  return pts.slice(0, 468).map(([x, y, z]) => {
    let X = x * 0.8;
    const Y = y * 1.08;
    let Z = z * 0.9;
    if (Y < -0.3) {
      const t = (-Y - 0.3) / 0.8;
      X *= 1 - 0.35 * t * t;
      Z *= 1 - 0.15 * t;
    }
    const f = Math.max(0, z);
    Z += 0.24 * Math.exp(-((X * X) / 0.01 + ((Y + 0.05) * (Y + 0.05)) / 0.05)) * f;
    const ex = (Math.abs(X) - 0.28) ** 2;
    const ey = (Y - 0.2) ** 2;
    Z -= 0.09 * Math.exp(-(ex / 0.012 + ey / 0.008)) * f;
    return [X, Y, Z];
  });
}
